
// ----------------------------------------------------------------------


const AuthRoutes = [

]

export default AuthRoutes
