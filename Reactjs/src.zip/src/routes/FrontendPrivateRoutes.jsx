// import LoanApplicationForm from 'src/pages/Frontend/Loan/LoanApplicationForm'

const FrontendPrivateRoutes = [
    // {
    //     path: '/loan', 
    //     element: <LoanApplicationForm />
    // },
]


export default FrontendPrivateRoutes;