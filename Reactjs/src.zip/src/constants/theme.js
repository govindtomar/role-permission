export const DRAWER_WIDTH = 240;

export const APPBAR_MOBILE = 64;

export const APPBAR_DESKTOP = 65;

export const WEB_WIDTH = '1280px'

export const INNER_CONTAINER_HEIGHT = '2rem 0';