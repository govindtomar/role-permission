import * as Yup from "yup";
import { useNavigate, useParams } from "react-router-dom";
import { useFormik } from "formik";
import { useSelector, useDispatch } from "react-redux";
import {
  editPermissionModule,
  showPermissionModule,
} from "src/store/api/permission-module";
import { Stack, Container, Typography, Button, Grid, TextField } from "@mui/material";
import Iconify from "src/components/Iconify";
import FormProvider from "src/components/FormProvider";
import { useEffect, Fragment } from "react";
import { SaveButton } from "src/components/Button";
import { slugConvertor } from "src/helpers/StringHelper";
import BreadcrumbNavigator from "src/components/BreadcrumbNavigator";

// ----------------------------------------------------------------------

export default function EditPermissionModule() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const params = useParams();
  const { permission_module } = useSelector((state) => state.permission_module);

  useEffect(() => {
    const id = params.id;
    dispatch(showPermissionModule({ id }));
  }, [params]);

  useEffect(() => {
    if (permission_module !== null) {
      formik.setValues({
        id: permission_module.id,
        name: permission_module.name,
        module_api: permission_module.module_api,
      });
    }
  }, [permission_module]);

  const formik = useFormik({
    initialValues: {
      name: "",
      module_api: "",
    },
    validationSchema: Yup.object({
      name: Yup.string().required("Permission Module is required"),
      module_api: Yup.string().required("Permission Module API is required"),
    }),
    onSubmit: (formValue) => {
      formValue.module_api = slugConvertor(formValue.module_api);
      dispatch(editPermissionModule({ formValue, navigate }));
    },
  });

  const breadcrumbNavigate = [
    {
      name: "permission-module",
      link: "/permission-module",
    },
  ];

  return (
    <Fragment>
      <BreadcrumbNavigator
        navigate={breadcrumbNavigate}
        currentPage="Edit PermissionModule"
      />
      <FormProvider onSubmit={formik.handleSubmit}>
        <Grid container spacing={3}>
          <Grid item xs={7}>
            <TextField
              error={Boolean(formik.touched.name && formik.errors.name)}
              fullWidth
              helperText={formik.touched.name && formik.errors.name}
              label="Permission Module Name"
              margin="normal"
              name="name"
              onBlur={formik.handleBlur}
              onChange={formik.handleChange}
              value={formik.values.name}
              variant="outlined"
              color="form"
            />
          </Grid>
          <Grid item xs={7}>
            <TextField
              error={Boolean(
                formik.touched.module_api && formik.errors.module_api
              )}
              fullWidth
              helperText={formik.touched.module_api && formik.errors.module_api}
              label="Permission Module API"
              margin="normal"
              name="module_api"
              onBlur={formik.handleBlur}
              onChange={formik.handleChange}
              value={formik.values.module_api}
              variant="outlined"
              color="form"
            />
          </Grid>
          <Grid item xs={6}>
            <SaveButton type="submit">Save</SaveButton>
          </Grid>
        </Grid>
      </FormProvider>
    </Fragment>
  );
}
