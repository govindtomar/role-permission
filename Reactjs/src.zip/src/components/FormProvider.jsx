import PropTypes from 'prop-types';
import {  
  Card, 
  Container
} from '@mui/material';

// ----------------------------------------------------------------------

FormProvider.propTypes = {
  children: PropTypes.node.isRequired,
  onSubmit: PropTypes.func,
};

export default function FormProvider({ children, onSubmit }) {
  return (
    <Card>
      <Container sx={{
        margin:'2rem 0'
      }}>
          <form onSubmit={onSubmit}>{children}</form>
      </Container>
    </Card>
  );
}
