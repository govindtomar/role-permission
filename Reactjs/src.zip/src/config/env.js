export const API_URL =  'http://local.dice.com/api';

// export const FRONT_API_URL = process.env.VITE_APP_API_URL + '/api/v1/f/';

// export const BACK_API_URL = process.env.VITE_APP_API_URL + '/api/v1/b/';

// export const ONLY_API_URL = process.env.VITE_APP_API_URL;

// export const ASSET_URL = process.env.VITE_APP_API_URL + '/';

// export const APP_URL = process.env.VITE_APP_URL;

// export const BASE_NAME = process.env.VITE_APP_BASE_NAME;